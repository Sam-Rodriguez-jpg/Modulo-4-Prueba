// Importo las librerias que se van a utilizar
const express = require('express');
const cors = require('cors');
const db = require('./db.js');
const { 
    uploadClientsFromCSV,
    uploadAddressesFromCSV,
    uploadEmailsFromCSV,
    uploadPhonesNumbersFromCSV,
    uploadInvoicesFromCSV,
    uploadTransactionsFromCSV
} = require('./csvHandler.js'); // IMPORTANTE: La funcion para que lea los CSV y crear el endpoint

// Instacia de Express
const app = express();
const PORT = 3000; // El puerto donde va a correr el servidor

// Middleware (Para otros dominios externos y poder hacer peticiones)
app.use(cors());
app.use(express.json()); // Habilita Express para recibir y entender datos en formato JSON en el body de las peticiones


// -------------------- Endpoint General --------------------
// GET - Endpoint traer todo los datos de la tabla sin ids
app.get('/getGeneral', (request, response) => {

    // Consulta SQL que trae todo
    const query = `SELECT 
    c.id_client,
    c.name,
    c.last_name,
    c.document,
    c.platform,
    a.address,
    e.email,
    p.phone_number,
    i.invoice_number,
    i.invoice_period,
    i.invoiced_amount,
    i.amount_paid,
    tr.datetime_transaction,
    tr.transaction_status,
    tr.transaction_type,
    tr.transaction_amount
    FROM clients c
    LEFT JOIN addresses a ON c.id_client = a.id_client
    LEFT JOIN emails e ON c.id_client = e.id_client
    LEFT JOIN phones_numbers p ON c.id_client = p.id_client
    LEFT JOIN transactions tr ON c.id_client = tr.id_client
    LEFT JOIN invoices i ON tr.id_invoice = i.id_invoice
`;

    // Ejecutamos la consulta usando nuestra conexión a la base de datos
    db.query(query, (error, result) => {

        // Si ocurre un error en la base de datos
        if(error) {
            return response.status(500).json({
                status: 'error', // Estado de error
                message: 'Error al obtener la tabla', // Mensaje descriptivo
                error: error.message // Detalle técnico del error
            });
        }

        // Si todo sale bien
        response.status(200).json({
            status: 'success', // Estado de exito
            message: 'Tabla obtenida correctamente', // Mensaje descriptivo
            data: result // Datos obtenidos desde MySQL
        });
    });
});
// Para probar en Postman: http://localhost:3000/getGeneral



// -------------------- Endpoint Solicitados --------------------
// GET - Total pagado por cada cliente
app.get('/firstQuery', (request, response) => {
    const query = `
        SELECT 
        c.id_client,
        c.name,
        c.last_name,
        SUM(i.amount_paid) AS total_pagado
        FROM clients c
        LEFT JOIN transactions tr ON c.id_client = tr.id_client
        LEFT JOIN invoices i ON tr.id_invoice = i.id_invoice
        GROUP BY c.id_client, c.name, c.last_name
        ORDER BY total_pagado DESC;
    `;

    db.query(query, (error, result) => {

        // Si ocurre un error en la base de datos
        if(error) {
            return response.status(500).json({
                status: 'error', // Estado de error
                message: 'Error al obtener la tabla', // Mensaje descriptivo
                error: error.message // Detalle técnico del error
            });
        }

        // Si todo sale bien
        response.status(200).json({
            status: 'success', // Estado de exito
            message: 'Tabla obtenida correctamente', // Mensaje descriptivo
            data: result // Datos obtenidos desde MySQL
        });
    });
});
// Para probar en Postman: http://localhost:3000/firstQuery

// GET - Facturas pendientes con información de cliente y transacción asociada
app.get('/secondQuery', (request, response) => {
    const query = `
        SELECT 
        c.id_client,
        c.name,
        c.last_name,
        i.invoice_number,
        i.invoiced_amount,
        i.amount_paid,
        tr.id_transaction,
        tr.datetime_transaction,
        tr.transaction_status
        FROM clients c
        LEFT JOIN transactions tr ON c.id_client = tr.id_client
        LEFT JOIN invoices i ON tr.id_invoice = i.id_invoice
        WHERE i.amount_paid < i.invoiced_amount
        ORDER BY c.id_client, i.invoice_number;
    `;

    db.query(query, (error, result) => {

        // Si ocurre un error en la base de datos
        if(error) {
            return response.status(500).json({
                status: 'error', // Estado de error
                message: 'Error al obtener la tabla', // Mensaje descriptivo
                error: error.message // Detalle técnico del error
            });
        }

        // Si todo sale bien
        response.status(200).json({
            status: 'success', // Estado de exito
            message: 'Tabla obtenida correctamente', // Mensaje descriptivo
            data: result // Datos obtenidos desde MySQL
        });
    });
});
// Para probar en Postman: http://localhost:3000/secondQuery

// GET - Listado de transacciones por plataforma
app.get('/thirdQuery', (request, response) => {
    const query = `
        SELECT 
        c.id_client,
        c.name,
        c.last_name,
        c.platform,
        tr.id_transaction,
        tr.datetime_transaction,
        tr.transaction_type,
        tr.transaction_amount,
        i.invoice_number
        FROM clients c
        LEFT JOIN transactions tr ON c.id_client = tr.id_client
        LEFT JOIN invoices i ON tr.id_invoice = i.id_invoice
        WHERE c.platform = 'Nequi' or c.platform = 'Daviplata'
        ORDER BY tr.datetime_transaction DESC;
    `;

    db.query(query, (error, result) => {

        // Si ocurre un error en la base de datos
        if(error) {
            return response.status(500).json({
                status: 'error', // Estado de error
                message: 'Error al obtener la tabla', // Mensaje descriptivo
                error: error.message // Detalle técnico del error
            });
        }

        // Si todo sale bien
        response.status(200).json({
            status: 'success', // Estado de exito
            message: 'Tabla obtenida correctamente', // Mensaje descriptivo
            data: result // Datos obtenidos desde MySQL
        });
    });
});
// Para probar en Postman: http://localhost:3000/thirdQuery



// -------------------- CSVs Endpoints --------------------
// POST - Endpoint para insertar todos los registros de clientes
app.post('/postClientsCSV', (request, response) => {
    uploadClientsFromCSV();
    response.send('Carga masiva de clientes iniciada');
});
// Para probar en Postman: // Para probar en Postman: http://localhost:3000/postClientsCSV

// POST - Endpoint para insertar todos los registros de direcciones
app.post('/postAddressCSV', (request, response) => {
    uploadAddressesFromCSV();
    response.send('Carga masiva de direcciones iniciada');
});
// Para probar en Postman: // Para probar en Postman: http://localhost:3000/postAddressCSV

// POST - Endpoint para insertar todos los registros de correos
app.post('/postEmailsCSV', (request, response) => {
    uploadEmailsFromCSV();
    response.send('Carga masiva de correos iniciada');
});
// Para probar en Postman: // Para probar en Postman: http://localhost:3000/postEmailsCSV

// POST - Endpoint para insertar todos los registros de telefonos
app.post('/postPhonesNumbersCSV', (request, response) => {
    uploadPhonesNumbersFromCSV();
    response.send('Carga masiva de telefonos iniciada');
});
// Para probar en Postman: // Para probar en Postman: http://localhost:3000/postPhonesNumbersCSV

// POST - Endpoint para insertar todos los registros de facturas
app.post('/postInvoicesCSV', (request, response) => {
    uploadInvoicesFromCSV();
    response.send('Carga masiva de facturas iniciada');
});
// Para probar en Postman: // Para probar en Postman: http://localhost:3000/postInvoicesCSV

// POST - Endpoint para insertar todos los registros de transacciones
app.post('/postTransactionsCSV', (request, response) => {
    uploadTransactionsFromCSV();
    response.send('Carga masiva de transacciones iniciada');
});
// Para probar en Postman: // Para probar en Postman: http://localhost:3000/postTransactionsCSV






// -------------------- CRUD Clients --------------------
// GET - Endpoint para traer los clientes
app.get('/getClients', (request, response) => {

    // Consulta SQL para traer todos los registros dentro de 'clients'
    const query = 'SELECT * FROM clients';

    // Ejecutamos la consulta usando nuestra conexión a la base de datos
    db.query(query, (error, result) => {

        // Si ocurre un error en la base de datos
        if(error) {
            return response.status(500).json({
                status: 'error', // Estado de error
                message: 'Error al obtener los clientes', // Mensaje descriptivo
                error: error.message // Detalle técnico del error
            });
        }

        // Si todo sale bien
        response.status(200).json({
            status: 'success', // Estado de exito
            message: 'Lista de clientes obtenida correctamente', // Mensaje descriptivo
            data: result // Datos obtenidos desde MySQL
        });
    });
});
// Para probar en Postman: http://localhost:3000/getClients

// POST - Endpoint para crear un nuevo cliente
app.post('/postClient', (request, response) => {
    // Extraigo los datos enviados en el body de la petición
    const data = request.body;

    // Validamos que no falte ningún campo obligatorio
    if (!data.name || !data.last_name || !data.document || !data.platform) {
        return response.status(400).json({
            status: 'error',
            message: 'Todos los datos deben ser obligatorios para crear el cliente'
        });
    }

    // Consulta SQL para insertar el nuevo cliente y usando placeholders (?) para evitar la inyeccion SQL
    const query = `
        INSERT INTO clients (name, last_name, document, platform)
        VALUES (?, ?, ?, ?)
    `;

    // Array con los valores en el mismo orden que la consulta para guardarlos en una variable y poderlos manejar más facilmente
    const values = [
        data.name,
        data.last_name,
        data.document,
        data.platform
    ];

    // Ejecutar la consulta
    db.query(query, values, (error, result) => {
        // En caso de error
        if(error) { 
            return response.status(500).json({
                status: 'success',
                message: 'Error al insertar el cliente',
                error: error.message
            });
        }

        // Si todo funciona
        response.status(201).json({
            status: 'success',
            message: 'Cliente agregado correctamente',
            data: {
                id_client: result.insertId, // ID autogenerado por MySQL
                name: data.name,
                last_name: data.last_name,
                document: data.document
            }
        });                     
    });
});
// Para probar en Postman: http://localhost:3000/postClient

// PUT - Endpoint para actualizar un cliente
app.put('/updateClient/:id', (request, response) => {

    // Extrigo el ID de la URL
    const id_client = request.params.id;

    // Extraigo los datos enviados en el body de la petición
    const data = request.body;

    // Validamos que todos los campos esten presentes 
    if (!data.name || !data.last_name || !data.document || !data.platform) {
        return response.status(400).json({
            status: 'error',
            message: 'Todos los datos deben ser obligatorios para crear el cliente'
        });
    }

    // Consulta SQL para actualizar el empleado y usando placeholders (?) para evitar la inyeccion SQL
    const query = `
        UPDATE clients
        SET name = ?, last_name = ?, document = ?, platform = ?
        WHERE id_client = ?
    `;

     // Array con los valores en el mismo orden que la consulta para guardarlos en una variable y poderlos manejar más facilmente
    const values = [
        data.name,
        data.last_name,
        data.document,
        data.platform,
        id_client // IMPORTANTE: Que no se te olvide a la proxima
    ];

    // Ejecutar la consulta
    db.query(query, values, (error, result) => {
        // En caso de error
        if(error) { 
            return response.status(500).json({
                status: 'success',
                message: 'Error al actualizar el cliente',
                error: error.message
            });
        }

        // Verificación de que se actualizo algo
        if(result.affectedRows === 0) {
            return response.status(404).json({
                status: 'error',
                message: `No se encontró el cliente con el ID: ${id_client}`
            });
        }

        // Si todo salio bien
        response.status(200).json({
            status: 'success',
            message: `Cliente con el ID: ${id_employee} actualizado correctamente`
        });
    });
});
// Para probar en Postman: http://localhost:3000/updateClient/[id]

// DELETE - Endpoint para eliminar un cliente
app.delete('/deleteClient/:id', (request, response) => {

    // Extraemeos el ID desde los parametros de la URL
    const id_client = request.params.id;

    // Consulta SQL para eliminar el cliente y usando placeholders (?) para evitar la inyeccion SQL
    const query = `
        DELETE FROM client
        WHERE id_client = ?
    `;

    // Ejecutamos la consulta
    db.query(query, [id_client], (error, result) => {

        // Si hay error en la base de datos
        if(error) {
            return response.status(500).json({
                status: 'error',
                message: 'Error al eliminar el cliente',
                error: error.message
            });
        }

        // Si no encuentra el ID
        if(result.affectedRows === 0) {
            return response.status(404).json({
                status: 'error',
                message: 'Cliente no encontrado'
            });
        }

        // Si todo funciono bien
        response.status(200).json({
            status: 'success',
            message: `Cliente con ID: ${id_client} eliminado correctamente`
        });
    });
});
// Para probar en Postman: http://localhost:3000/deleteClient/[id]
// IMPORTANTE: Apartir de aqui no puse comentarios porque era la misma información pero con diferentes valores





// -------------------- CRUD Addresses --------------------
// GET - Endpoint para traer las direcciones
app.get('/getAddresses', (request, response) => {
    const query = 'SELECT * FROM address';

    db.query(query, (error, result) => {
        if(error) {
            return response.status(500).json({
                status: 'error',
                message: 'Error al obtener las direcciones',
                error: error.message
            });
        }

        response.status(200).json({
            status: 'success',
            message: 'Lista de direcciones obtenida correctamente',
            data: result
        });
    });
});
// Para probar en Postman: http://localhost:3000/getAddresses

// POST - Endpoint para crear una nueva direccion
app.post('/postAddress', (request, response) => {
    const data = request.body;

    if (!data.address || !data.id_client) {
        return response.status(400).json({
            status: 'error',
            message: 'Todos los datos deben ser obligatorios para crear la direccion'
        });
    }

    const query = `
        INSERT INTO addresses (address, id_client)
        VALUES (?, ?)
    `;

    const values = [
        data.address,
        data.id_client
    ];

    db.query(query, values, (error, result) => {
        if(error) { 
            return response.status(500).json({
                status: 'success',
                message: 'Error al insertar la direccion',
                error: error.message
            });
        }

        response.status(201).json({
            status: 'success',
            message: 'Direccion agregada correctamente',
            data: {
                id_address: result.insertId,
                address: data.address,
                id_client: data.id_client
            }
        });                     
    });
});
// Para probar en Postman: http://localhost:3000/postAddress

// PUT - Endpoint para actualizar una dirrecion
app.put('/updateAddress/:id', (request, response) => {
    const id_address = request.params.id;
    const data = request.body;

    if (!data.address || !data.id_client) {
        return response.status(400).json({
            status: 'error',
            message: 'Todos los datos deben ser obligatorios para crear la direccion'
        });
    }

    const query = `
        UPDATE addresses
        SET address = ?, id_client = ?
        WHERE id_address = ?
    `;

    const values = [
        data.address,
        data.id_client,
        id_address
    ];

    db.query(query, values, (error, result) => {
        if(error) { 
            return response.status(500).json({
                status: 'success',
                message: 'Error al actualizar la direccion',
                error: error.message
            });
        }

        if(result.affectedRows === 0) {
            return response.status(404).json({
                status: 'error',
                message: `No se encontró la direccion con el ID: ${id_address}`
            });
        }

        response.status(200).json({
            status: 'success',
            message: `Dirrecion con el ID: ${id_address} actualizado correctamente`
        });
    });
});
// Para probar en Postman: http://localhost:3000/updateAddress/[id]

// DELETE - Endpoint para eliminar una direccion
app.delete('/deleteAddress/:id', (request, response) => {
    const id_address = request.params.id;
    const query = `
        DELETE FROM address
        WHERE id_address = ?
    `;

    db.query(query, [id_address], (error, result) => {

        if(error) {
            return response.status(500).json({
                status: 'error',
                message: 'Error al eliminar una direccion',
                error: error.message
            });
        }

        if(result.affectedRows === 0) {
            return response.status(404).json({
                status: 'error',
                message: 'Direccion no encontrada'
            });
        }

        response.status(200).json({
            status: 'success',
            message: `Direccion con ID: ${id_address} eliminado correctamente`
        });
    });
});
// Para probar en Postman: http://localhost:3000/deleteAddress/[id]





// -------------------- CRUD Emails --------------------
// GET - Endpoint para traer los correos
app.get('/getEmails', (request, response) => {
    const query = 'SELECT * FROM emails';

    db.query(query, (error, result) => {
        if(error) {
            return response.status(500).json({
                status: 'error',
                message: 'Error al obtener los correos',
                error: error.message
            });
        }

        response.status(200).json({
            status: 'success',
            message: 'Lista de correos obtenida correctamente',
            data: result
        });
    });
});
// Para probar en Postman: http://localhost:3000/getEmails

// POST - Endpoint para crear una nuevo correo
app.post('/postEmail', (request, response) => {
    const data = request.body;

    if (!data.email || !data.id_client) {
        return response.status(400).json({
            status: 'error',
            message: 'Todos los datos deben ser obligatorios para crear el correo'
        });
    }

    const query = `
        INSERT INTO emails (email, id_client)
        VALUES (?, ?)
    `;

    const values = [
        data.email,
        data.id_client
    ];

    db.query(query, values, (error, result) => {
        if(error) { 
            return response.status(500).json({
                status: 'success',
                message: 'Error al insertar el correo',
                error: error.message
            });
        }

        response.status(201).json({
            status: 'success',
            message: 'Correo agregado correctamente',
            data: {
                id_email: result.insertId,
                email: data.email,
                id_client: data.id_client
            }
        });                     
    });
});
// Para probar en Postman: http://localhost:3000/postEmail

// PUT - Endpoint para actualizar un correo
app.put('/updateEmail/:id', (request, response) => {
    const id_email = request.params.id;
    const data = request.body;

    if (!data.email || !data.id_client) {
        return response.status(400).json({
            status: 'error',
            message: 'Todos los datos deben ser obligatorios para crear el correo'
        });
    }

    const query = `
        UPDATE emails
        SET email = ?, id_client = ?
        WHERE id_email = ?
    `;

    const values = [
        data.email,
        data.id_client,
        id_email
    ];

    db.query(query, values, (error, result) => {
        if(error) { 
            return response.status(500).json({
                status: 'success',
                message: 'Error al actualizar el correo',
                error: error.message
            });
        }

        if(result.affectedRows === 0) {
            return response.status(404).json({
                status: 'error',
                message: `No se encontró el correo con el ID: ${id_email}`
            });
        }

        response.status(200).json({
            status: 'success',
            message: `Correo con el ID: ${id_email} actualizado correctamente`
        });
    });
});
// Para probar en Postman: http://localhost:3000/updateEmail/[id]

// DELETE - Endpoint para eliminar un correo
app.delete('/deleteEmail/:id', (request, response) => {
    const id_email = request.params.id;
    const query = `
        DELETE FROM email
        WHERE id_email = ?
    `;

    db.query(query, [id_email], (error, result) => {

        if(error) {
            return response.status(500).json({
                status: 'error',
                message: 'Error al eliminar un correo',
                error: error.message
            });
        }

        if(result.affectedRows === 0) {
            return response.status(404).json({
                status: 'error',
                message: 'Correo no encontrado'
            });
        }

        response.status(200).json({
            status: 'success',
            message: `Correo con ID: ${id_email} eliminado correctamente`
        });
    });
});
// Para probar en Postman: http://localhost:3000/deleteEmail/[id]






// -------------------- CRUD Phones Numbers --------------------
// GET - Endpoint para traer las transacciones
app.get('/getPhoneNumbers', (request, response) => {
    const query = 'SELECT * FROM phones_numbers';

    db.query(query, (error, result) => {
        if(error) {
            return response.status(500).json({
                status: 'error',
                message: 'Error al obtener los telefonos',
                error: error.message
            });
        }

        response.status(200).json({
            status: 'success',
            message: 'Lista de telefonos obtenida correctamente',
            data: result
        });
    });
});
// Para probar en Postman: http://localhost:3000/getTransactions

// POST - Endpoint para crear una nueva transaccion
app.post('/postPhoneNumber', (request, response) => {
    const data = request.body;

    if (!data.phone_number || !data.id_client) {
        return response.status(400).json({
            status: 'error',
            message: 'Todos los datos deben ser obligatorios para crear el telefono'
        });
    }

    const query = `
        INSERT INTO phones_numbers (phone_number, id_client)
        VALUES (?, ?)
    `;

    const values = [
        data.phone_number,
        data.id_client
    ];

    db.query(query, values, (error, result) => {
        if(error) { 
            return response.status(500).json({
                status: 'success',
                message: 'Error al insertar el telefono',
                error: error.message
            });
        }

        response.status(201).json({
            status: 'success',
            message: 'Telefono agregada correctamente',
            data: {
                id_phone_number: result.insertId,
                phone_number: data.phone_number,
                id_client: data.id_client
            }
        });                     
    });
});
// Para probar en Postman: http://localhost:3000/postPhoneNumber

// PUT - Endpoint para actualizar un telefono
app.put('/updatePhoneNumber/:id', (request, response) => {
    const id_phone_number = request.params.id;
    const data = request.body;

    if (!data.phone_number || !data.id_client) {
        return response.status(400).json({
            status: 'error',
            message: 'Todos los datos deben ser obligatorios para crear el telefono'
        });
    }

    const query = `
        UPDATE phones_numbers
        SET phone_number = ?, id_client = ?
        WHERE id_phone_number = ?
    `;

    const values = [
        data.phone_number,
        data.id_client,
        id_phone_number
    ];

    db.query(query, values, (error, result) => {
        if(error) { 
            return response.status(500).json({
                status: 'success',
                message: 'Error al actualizar el telefono',
                error: error.message
            });
        }

        if(result.affectedRows === 0) {
            return response.status(404).json({
                status: 'error',
                message: `No se encontró el telefono con el ID: ${id_phone_number}`
            });
        }

        response.status(200).json({
            status: 'success',
            message: `Telefono con el ID: ${id_phone_number} actualizado correctamente`
        });
    });
});
// Para probar en Postman: http://localhost:3000/updatePhoneNumber/[id]

// DELETE - Endpoint para eliminar un telefono
app.delete('/deletePhoneNumber/:id', (request, response) => {
    const id_phone_number = request.params.id;
    const query = `
        DELETE FROM phones_numbers
        WHERE id_phone_number = ?
    `;

    db.query(query, [id_phone_number], (error, result) => {

        if(error) {
            return response.status(500).json({
                status: 'error',
                message: 'Error al eliminar un telefono',
                error: error.message
            });
        }

        if(result.affectedRows === 0) {
            return response.status(404).json({
                status: 'error',
                message: 'Telefono no encontrado'
            });
        }

        response.status(200).json({
            status: 'success',
            message: `Telefono con ID: ${id_phone_number} eliminado correctamente`
        });
    });
});
// Para probar en Postman: http://localhost:3000/deletePhoneNumber/[id]





// -------------------- CRUD Invoices --------------------
// GET - Endpoint para traer las facturas
app.get('/getInvoices', (request, response) => {
    const query = 'SELECT * FROM invoices';

    db.query(query, (error, result) => {
        if(error) {
            return response.status(500).json({
                status: 'error',
                message: 'Error al obtenerlas facturas',
                error: error.message
            });
        }

        response.status(200).json({
            status: 'success',
            message: 'Lista de facturas obtenida correctamente',
            data: result
        });
    });
});
// Para probar en Postman: http://localhost:3000/getInvoices

// POST - Endpoint para crear una nueva factura
app.post('/postInvoice', (request, response) => {
    const data = request.body;

    if (!data.invoice_number || !data.invoice_period || !data.invoiced_amount || !data.amount_paid) {
        return response.status(400).json({
            status: 'error',
            message: 'Todos los datos deben ser obligatorios para crear la factura'
        });
    }

    const query = `
        INSERT INTO emails (invoice_number, invoice_period, invoiced_amount, amount_paid)
        VALUES (?, ?, ?, ?)
    `;

    const values = [
        data.invoice_number,
        data.invoice_period,
        data.invoiced_amount,
        data.amount_paid
    ];

    db.query(query, values, (error, result) => {
        if(error) { 
            return response.status(500).json({
                status: 'success',
                message: 'Error al insertar la factura',
                error: error.message
            });
        }

        response.status(201).json({
            status: 'success',
            message: 'Factura agregado correctamente',
            data: {
                id_invoice: result.insertId,
                invoice_number: data.invoice_number,
                invoice_period: data.invoice_period,
                invoiced_amount: data.invoiced_amount,
                amount_paid: data.amount_paid
            }
        });                     
    });
});
// Para probar en Postman: http://localhost:3000/postInvoice

// PUT - Endpoint para actualizar una factura
app.put('/updateInvoice/:id', (request, response) => {
    const id_invoice = request.params.id;
    const data = request.body;

    if (!data.invoice_number || !data.invoice_period || !data.invoiced_amount || !data.amount_paid) {
        return response.status(400).json({
            status: 'error',
            message: 'Todos los datos deben ser obligatorios para crear la factura'
        });
    }

    const query = `
        UPDATE invoices
        SET invoice_number = ?, invoice_period = ?, invoiced_amount = ?, amount_paid = ?
        WHERE id_invoice = ?
    `;

    const values = [
        data.invoice_number,
        data.invoice_period,
        data.invoiced_amount,
        data.amount_paid,
        id_invoice
    ];

    db.query(query, values, (error, result) => {
        if(error) { 
            return response.status(500).json({
                status: 'success',
                message: 'Error al actualizar la factura',
                error: error.message
            });
        }

        if(result.affectedRows === 0) {
            return response.status(404).json({
                status: 'error',
                message: `No se encontró la factura con el ID: ${id_invoice}`
            });
        }

        response.status(200).json({
            status: 'success',
            message: `Factura con el ID: ${id_invoice} actualizado correctamente`
        });
    });
});
// Para probar en Postman: http://localhost:3000/updateInvoice/[id]

// DELETE - Endpoint para eliminar una factura
app.delete('/deleteInvoice/:id', (request, response) => {
    const id_invoice = request.params.id;
    const query = `
        DELETE FROM invoices
        WHERE id_invoice = ?
    `;

    db.query(query, [id_invoice], (error, result) => {

        if(error) {
            return response.status(500).json({
                status: 'error',
                message: 'Error al eliminar una factura',
                error: error.message
            });
        }

        if(result.affectedRows === 0) {
            return response.status(404).json({
                status: 'error',
                message: 'Factura no encontrada'
            });
        }

        response.status(200).json({
            status: 'success',
            message: `Factura con ID: ${id_invoice} eliminada correctamente`
        });
    });
});
// Para probar en Postman: http://localhost:3000/deleteInvoice/[id]





// -------------------- CRUD Transactions --------------------
// GET - Endpoint para traer las transacciones
app.get('/getTransactions', (request, response) => {
    const query = 'SELECT * FROM transactions';

    db.query(query, (error, result) => {
        if(error) {
            return response.status(500).json({
                status: 'error',
                message: 'Error al obtener las transacciones',
                error: error.message
            });
        }

        response.status(200).json({
            status: 'success',
            message: 'Lista de transacciones obtenida correctamente',
            data: result
        });
    });
});
// Para probar en Postman: http://localhost:3000/getTransactions

// POST - Endpoint para crear una nueva transaccion
app.post('/postTransaction', (request, response) => {
    const data = request.body;

    if (!data.datatime_transaction || !data.transaction_status || !data.transaction_type || !data.transaction_amount || !data.id_client || !data.id_invoice) {
        return response.status(400).json({
            status: 'error',
            message: 'Todos los datos deben ser obligatorios para crear la transacción'
        });
    }

    const query = `
        INSERT INTO emails (datatime_transaction, transaction_status, transaction_type, transaction_amount, id_client, id_invoice)
        VALUES (?, ?, ?, ?, ?, ?)
    `;

    const values = [
        data.datatime_transaction,
        data.transaction_status,
        data.transaction_type,
        data.transaction_amount,
        data.id_client,
        data.id_invoice
    ];

    db.query(query, values, (error, result) => {
        if(error) { 
            return response.status(500).json({
                status: 'success',
                message: 'Error al insertar la transacción',
                error: error.message
            });
        }

        response.status(201).json({
            status: 'success',
            message: 'Transacción agregada correctamente',
            data: {
                id_transaction: result.insertId,
                datatime_transaction: data.datatime_transaction,
                transaction_status: data.transaction_status,
                transaction_type: data.transaction_type,
                transaction_amount: data.transaction_amount,
                id_client: data.id_client,
                id_invoice: data.id_invoice
            }
        });                     
    });
});
// Para probar en Postman: http://localhost:3000/postTransaction

// PUT - Endpoint para actualizar una transacción
app.put('/updateTransaction/:id', (request, response) => {
    const id_transaction = request.params.id;
    const data = request.body;

    if (!data.datatime_transaction || !data.transaction_status || !data.transaction_type || !data.transaction_amount || !data.id_client || !data.id_invoice) {
        return response.status(400).json({
            status: 'error',
            message: 'Todos los datos deben ser obligatorios para crear la transacción'
        });
    }

    const query = `
        UPDATE transactions
        SET datatime_transaction = ?, transaction_status = ?, transaction_type = ?, transaction_amount = ?, id_client = ?, id_invoice = ?
        WHERE id_transaction = ?
    `;

    const values = [
        data.datatime_transaction,
        data.transaction_status,
        data.transaction_type,
        data.transaction_amount,
        data.id_client,
        data.id_invoice,
        id_transaction
    ];

    db.query(query, values, (error, result) => {
        if(error) { 
            return response.status(500).json({
                status: 'success',
                message: 'Error al actualizar la transacción',
                error: error.message
            });
        }

        if(result.affectedRows === 0) {
            return response.status(404).json({
                status: 'error',
                message: `No se encontró la transacción con el ID: ${id_transaction}`
            });
        }

        response.status(200).json({
            status: 'success',
            message: `Transacción con el ID: ${id_transaction} actualizada correctamente`
        });
    });
});
// Para probar en Postman: http://localhost:3000/updateInvoice/[id]

// DELETE - Endpoint para eliminar una transacción
app.delete('/deleteTransaction/:id', (request, response) => {
    const id_transaction = request.params.id;
    const query = `
        DELETE FROM transactions
        WHERE id_transaction = ?
    `;

    db.query(query, [id_transaction], (error, result) => {

        if(error) {
            return response.status(500).json({
                status: 'error',
                message: 'Error al eliminar una transacción',
                error: error.message
            });
        }

        if(result.affectedRows === 0) {
            return response.status(404).json({
                status: 'error',
                message: 'Transacción no encontrada'
            });
        }

        response.status(200).json({
            status: 'success',
            message: `Transacción con ID: ${id_transaction} eliminada correctamente`
        });
    });
});
// Para probar en Postman: http://localhost:3000/deleteTransaction/[id]







// Levantar el servidor y que lo escuche en puerto ya definido (PORT = 3000)
app.listen(PORT, (error) => {
    if(error) {
        console.error(`Error al iniciar el servidor: ${error.message}`);
    } else {
        console.log(`Servidor corriendo en el puerto: ${PORT}`);
    }
});