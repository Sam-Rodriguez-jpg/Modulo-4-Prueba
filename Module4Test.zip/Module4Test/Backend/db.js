const mysql = require('mysql2');

// Configuración la conexión en la base de datos
const db = mysql.createConnection({
    host: 'localhost', // Servidor MySQL
    user: 'root', // Usuario del MySQL
    password: 'el290707', // Mi contraseña
    database: 'module4test_db' // Nombre de la base de datos tal cual la cree en MySQL
});

// Probar conexión
db.connect((error) => { // Le paso un error por si lo encuentra
    if (error) {
        console.error('Error al conectar a MySQL', error.message);
        return;
    }
    // Si todo funciona perfecto
    console.log('Conectado correctamente a MySQL!');
});

// IMPORTANTE para que otros archivos puedan conectarse a la base de datos
module.exports = db;