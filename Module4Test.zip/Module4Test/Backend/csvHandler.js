// Las librerias que vamos a utilizar
const fs = require('fs'); // Módulo para manejar archivos del sistema
const path = require('path'); // Módulo para manejar rutas de archivos
const csv = require('csv-parser'); // Para leer y parsear CSVs
const db = require('./db.js'); // Conexión a la base de datos
const { error } = require('console');



// -------------------- Funcion de insertar los clientes desde el CSV --------------------
const uploadClientsFromCSV = () => {
    const clients = []; // Array para almacenar los datos leídos del CSV

    // Definimos la ruta al archivo CSV
    const filePath = path.join(__dirname, '..', 'Database', 'clients.csv');

    // Creamos un stream de lectura desde el archivo CSV
    fs.createReadStream(filePath)
        .pipe(csv()) // Pipe del stream al parsear CSV para procesar fila por fila
        .on('data', (row) => {
            // Por cada fila leída, agregamos el objeto 'row' al array clients
            clients.push(row);
        })
        .on('end', () => {
            // Cuando terminamos de leer todo el archivo CSV, inicamos la inserción de base de datos
            console.log(`Archivo CSV leído. Total clientes: ${clients.length}`);

            // Insertamos cada empleado en la tabla 'clients' de la base de datos
            clients.forEach((client) => {

                // Consulta SQL con placeholders para prevenir inyección SQL
                const query = `
                    INSERT INTO clients (name, last_name, document, platform)
                    VALUES (?, ?, ?, ?)
                `;

                // Valores para los placeholders, obtenidos del objeto client (fila CSV)
                const values = [
                    client.name,
                    client.last_name,
                    client.document,
                    client.platform
                ];

                // Ejecutamos la consulta en la base de datos
                db.query(query, values, (error, result) => {
                    if(error) {
                        // Si ocurre un error
                        console.error('Error al insertar cliente:', error.message);
                    } else {
                        // Si todo sale bien
                        console.log(`Cliente insertado con ID: ${result.insertId}`);
                    }
                });
            });
        })
        .on('error', (error) => {
            // En caso de error al leer el archivo CSV, mostramos el error
            console.error('Error leyendo el archivo CSV:', error.message);
        });
};
// IMPORTANTE: Apartir de aqui no puse comentarios porque era la misma información pero con diferentes valores





// -------------------- Funcion de insertar las direciones desde el CSV --------------------
const uploadAddressesFromCSV = () => {
    const addresses = [];
    const filePath = path.join(__dirname, '..', 'Database', 'addresses.csv');

    fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => {
            addresses.push(row);
        })
        .on('end', () => {
            console.log(`Archivo CSV leído. Total direcciones: ${addresses.length}`);
            addresses.forEach((address) => {
                const query = `
                    INSERT INTO addresses (address, id_client)
                    VALUES (?, ?)
                `;

                const values = [
                    address.address,
                    address.id_client
                ];

                db.query(query, values, (error, result) => {
                    if(error) {
                        console.error('Error al insertar direccion:', error.message);
                    } else {
                        console.log(`Direccion insertado con ID: ${result.insertId}`);
                    }
                });
            });
        })
        .on('error', (error) => {
            console.error('Error leyendo el archivo CSV:', error.message);
        });
};






// -------------------- Funcion de insertar los correos desde el CSV --------------------
const uploadEmailsFromCSV = () => {
    const emails = [];
    const filePath = path.join(__dirname, '..', 'Database', 'emails.csv');

    fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => {
            emails.push(row);
        })
        .on('end', () => {
            console.log(`Archivo CSV leído. Total correos: ${emails.length}`);
            emails.forEach((email) => {
                const query = `
                    INSERT INTO emails (email, id_client)
                    VALUES (?, ?)
                `;

                const values = [
                    email.email,
                    email.id_client
                ];

                db.query(query, values, (error, result) => {
                    if(error) {
                        console.error('Error al insertar correos:', error.message);
                    } else {
                        console.log(`Correo insertado con ID: ${result.insertId}`);
                    }
                });
            });
        })
        .on('error', (error) => {
            console.error('Error leyendo el archivo CSV:', error.message);
        });
};




// -------------------- Funcion de insertar los telefonos desde el CSV --------------------
const uploadPhonesNumbersFromCSV = () => {
    const phonesNumbers = [];
    const filePath = path.join(__dirname, '..', 'Database', 'phones_numbers.csv');

    fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => {
            phonesNumbers.push(row);
        })
        .on('end', () => {
            console.log(`Archivo CSV leído. Total telefonos: ${phonesNumbers.length}`);
            phonesNumbers.forEach((phone_number) => {
                const query = `
                    INSERT INTO phones_numbers (phone_number, id_client)
                    VALUES (?, ?)
                `;

                const values = [
                    phone_number.phone_number,
                    phone_number.id_client
                ];

                db.query(query, values, (error, result) => {
                    if(error) {
                        console.error('Error al insertar telefonos:', error.message);
                    } else {
                        console.log(`Telefono insertado con ID: ${result.insertId}`);
                    }
                });
            });
        })
        .on('error', (error) => {
            console.error('Error leyendo el archivo CSV:', error.message);
        });
};





// -------------------- Funcion de insertar las facturas desde el CSV --------------------
const uploadInvoicesFromCSV = () => {
    const invoices = [];
    const filePath = path.join(__dirname, '..', 'Database', 'invoices.csv');

    fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => {
            invoices.push(row);
        })
        .on('end', () => {
            console.log(`Archivo CSV leído. Total telefonos: ${invoices.length}`);
            invoices.forEach((invoice) => {
                const query = `
                    INSERT INTO invoices (invoice_number, invoice_period, invoiced_amount, amount_paid)
                    VALUES (?, ?, ?, ?)
                `;

                const values = [
                    invoice.invoice_number,
                    invoice.invoice_period,
                    invoice.invoiced_amount,
                    invoice.amount_paid,
                ];

                db.query(query, values, (error, result) => {
                    if(error) {
                        console.error('Error al insertar facturas:', error.message);
                    } else {
                        console.log(`Factura insertada con ID: ${result.insertId}`);
                    }
                });
            });
        })
        .on('error', (error) => {
            console.error('Error leyendo el archivo CSV:', error.message);
        });
};






// -------------------- Funcion de insertar las transacciones desde el CSV --------------------
const uploadTransactionsFromCSV = () => {
    const transactions = [];
    const filePath = path.join(__dirname, '..', 'Database', 'transactions.csv');

    fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => {
            transactions.push(row);
        })
        .on('end', () => {
            console.log(`Archivo CSV leído. Total transacciones: ${transactions.length}`);
            transactions.forEach((transaction) => {
                const query = `
                    INSERT INTO transactions (datatime_transaction, transaction_status, transaction_type, transaction_amount, id_client, id_invoice)
                    VALUES (?, ?, ?, ?, ?, ?)
                `;

                const values = [
                    transaction.datatime_transaction,
                    transaction.transaction_status,
                    transaction.transaction_type,
                    transaction.transaction_amount,
                    transaction.id_client,
                    transaction.id_invoice,
                ];

                db.query(query, values, (error, result) => {
                    if(error) {
                        console.error('Error al transacciones facturas:', error.message);
                    } else {
                        console.log(`Transacción insertada con ID: ${result.insertId}`);
                    }
                });
            });
        })
        .on('error', (error) => {
            console.error('Error leyendo el archivo CSV:', error.message);
        });
};





// Exportamos las funciones para poder usarlas en otro archivo
module.exports = { 
    uploadClientsFromCSV,
    uploadAddressesFromCSV,
    uploadEmailsFromCSV,
    uploadPhonesNumbersFromCSV,
    uploadInvoicesFromCSV,
    uploadTransactionsFromCSV

}; // IMPORTANTE: Un solo module.exports