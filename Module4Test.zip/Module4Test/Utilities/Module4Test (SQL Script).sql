-- Module 4 - Test (SQL Tables)
SHOW DATABASES;
CREATE DATABASE IF NOT EXISTS module4test_db;
USE module4test_db;
SHOW TABLES;

-- En caso de necesitarlo, el orden de eliminación de tablas:
DROP TABLE transactions;
DROP TABLE invoices;
DROP TABLE phones_numbers;
DROP TABLE emails;
DROP TABLE addresses;
DROP TABLE clients;

-- Ver contenido de las tablas
SELECT * FROM clients;
SELECT * FROM addresses;
SELECT * FROM emails;
SELECT * FROM phones_numbers;
SELECT * FROM invoices;
SELECT * FROM transactions;

-- Orden: clients - address - emails - phones_numbers - invoices - transactions
CREATE TABLE IF NOT EXISTS clients(
	id_client INT AUTO_INCREMENT PRIMARY KEY,
	name VARCHAR(30) NOT NULL,
    last_name VARCHAR(30) NOT NULL,
    document INT NOT NULL UNIQUE,
    platform ENUM('Nequi', 'Daviplata')
);

CREATE TABLE IF NOT EXISTS addresses(
	id_address INT AUTO_INCREMENT PRIMARY KEY,
    address VARCHAR(100) NOT NULL UNIQUE,
    id_client INT,
    FOREIGN KEY (id_client) REFERENCES clients(id_client)
    ON UPDATE CASCADE
    ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS emails(
	email VARCHAR(50) NOT NULL UNIQUE,
    id_client INT,
    FOREIGN KEY (id_client) REFERENCES clients(id_client)
    ON UPDATE CASCADE
    ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS phones_numbers(
	id_phone_number INT AUTO_INCREMENT PRIMARY KEY,
	phone_number VARCHAR(25) NOT NULL UNIQUE,
    id_client INT,
    FOREIGN KEY (id_client) REFERENCES clients(id_client)
    ON UPDATE CASCADE
    ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS invoices(
	id_invoice INT AUTO_INCREMENT PRIMARY KEY,
    invoice_number VARCHAR(10) NOT NULL UNIQUE,
    invoice_period DATE NOT NULL,
    invoiced_amount INT NOT NULL,
    amount_paid INT NOT NULL
);

CREATE TABLE IF NOT EXISTS transactions(
	id_transaction INT AUTO_INCREMENT PRIMARY KEY,
    datetime_transaction DATETIME NOT NULL,
    transaction_status ENUM('Fallida', 'Pendiente', 'Completada') NOT NULL,
    transaction_type INT NOT NULL,
    transaction_amount INT NOT NULL,
    id_client INT,
    id_invoice INT,
    FOREIGN KEY (id_client) REFERENCES clients(id_client),
    FOREIGN KEY (id_invoice) REFERENCES invoices(id_invoice)
    ON UPDATE CASCADE
    ON DELETE RESTRICT
);

-- GET General
SELECT 
c.id_client,
c.name,
c.last_name,
c.document,
c.platform,
a.address,
e.email,
p.phone_number,
i.invoice_number,
i.invoice_period,
i.invoiced_amount,
i.amount_paid,
tr.datetime_transaction,
tr.transaction_status,
tr.transaction_type,
tr.transaction_amount
FROM clients c
LEFT JOIN addresses a ON c.id_client = a.id_client
LEFT JOIN emails e ON c.id_client = e.id_client
LEFT JOIN phones_numbers p ON c.id_client = p.id_client
LEFT JOIN transactions tr ON c.id_client = tr.id_client
LEFT JOIN invoices i ON tr.id_invoice = i.id_invoice;

-- Queries Solicitadas
-- 1.Total pagado por cada cliente
SELECT 
c.id_client,
c.name,
c.last_name,
SUM(i.amount_paid) AS total_pagado
FROM clients c
LEFT JOIN transactions tr ON c.id_client = tr.id_client
LEFT JOIN invoices i ON tr.id_invoice = i.id_invoice
GROUP BY c.id_client, c.name, c.last_name
ORDER BY total_pagado DESC;

-- 2. Facturas pendientes con información de cliente y transacción asociada
SELECT 
c.id_client,
c.name,
c.last_name,
i.invoice_number,
i.invoiced_amount,
i.amount_paid,
tr.id_transaction,
tr.datetime_transaction,
tr.transaction_status
FROM clients c
LEFT JOIN transactions tr ON c.id_client = tr.id_client
LEFT JOIN invoices i ON tr.id_invoice = i.id_invoice
WHERE i.amount_paid < i.invoiced_amount
ORDER BY c.id_client, i.invoice_number;

-- 3. Listado de transacciones por plataforma
SELECT 
c.id_client,
c.name,
c.last_name,
c.platform,
tr.id_transaction,
tr.datetime_transaction,
tr.transaction_type,
tr.transaction_amount,
i.invoice_number
FROM clients c
LEFT JOIN transactions tr ON c.id_client = tr.id_client
LEFT JOIN invoices i ON tr.id_invoice = i.id_invoice
WHERE c.platform = 'Nequi' or c.platform = 'Daviplata'
ORDER BY tr.datetime_transaction DESC;